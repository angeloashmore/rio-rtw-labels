/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/*!**************************!*\
  !*** ./src/end/index.js ***!
  \**************************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	__webpack_require__(/*! logger */ 1);
	
	var _jsLogger = __webpack_require__(/*! js-logger */ 2);
	
	var _jsLogger2 = _interopRequireDefault(_jsLogger);
	
	var _safari = __webpack_require__(/*! safari */ 4);
	
	var _safari2 = _interopRequireDefault(_safari);
	
	var _constants = __webpack_require__(/*! constants */ 3);
	
	var _messageHandlerShim = __webpack_require__(/*! messageHandlerShim */ 5);
	
	var _messageHandlerShim2 = _interopRequireDefault(_messageHandlerShim);
	
	var _messageHandlers = __webpack_require__(/*! end/messageHandlers */ 6);
	
	var messageHandlers = _interopRequireWildcard(_messageHandlers);
	
	var _actions = __webpack_require__(/*! end/actions */ 9);
	
	function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	function init() {
	  // Begin listening for messages.
	  var messageHandler = (0, _messageHandlerShim2.default)(messageHandlers);
	  _safari2.default.self.addEventListener(_constants.MESSAGE, messageHandler, false);
	  _jsLogger2.default.info('Now listening for messages');
	
	  // Begin observing mutations on QUERIES.ASSETS_PARENT.
	  (0, _actions.observe)(_constants.OBSERVATIONS.ASSETS_PARENT, _constants.QUERIES.ASSETS_PARENT, {
	    childList: true,
	    subtree: true
	  });
	}
	
	window.onload = init;

/***/ },
/* 1 */
/*!***********************!*\
  !*** ./src/logger.js ***!
  \***********************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	var _jsLogger = __webpack_require__(/*! js-logger */ 2);
	
	var _jsLogger2 = _interopRequireDefault(_jsLogger);
	
	var _constants = __webpack_require__(/*! constants */ 3);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	_jsLogger2.default.useDefaults({
	  formatter: function formatter(messages) {
	    return messages.unshift('[' + _constants.NAMESPACE + ']');
	  }
	});

/***/ },
/* 2 */
/*!***********************************!*\
  !*** ./~/js-logger/src/logger.js ***!
  \***********************************/
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_RESULT__;/*!
	 * js-logger - http://github.com/jonnyreeves/js-logger
	 * Jonny Reeves, http://jonnyreeves.co.uk/
	 * js-logger may be freely distributed under the MIT license.
	 */
	(function (global) {
		"use strict";
	
		// Top level module for the global, static logger instance.
		var Logger = { };
	
		// For those that are at home that are keeping score.
		Logger.VERSION = "1.2.0";
	
		// Function which handles all incoming log messages.
		var logHandler;
	
		// Map of ContextualLogger instances by name; used by Logger.get() to return the same named instance.
		var contextualLoggersByNameMap = {};
	
		// Polyfill for ES5's Function.bind.
		var bind = function(scope, func) {
			return function() {
				return func.apply(scope, arguments);
			};
		};
	
		// Super exciting object merger-matron 9000 adding another 100 bytes to your download.
		var merge = function () {
			var args = arguments, target = args[0], key, i;
			for (i = 1; i < args.length; i++) {
				for (key in args[i]) {
					if (!(key in target) && args[i].hasOwnProperty(key)) {
						target[key] = args[i][key];
					}
				}
			}
			return target;
		};
	
		// Helper to define a logging level object; helps with optimisation.
		var defineLogLevel = function(value, name) {
			return { value: value, name: name };
		};
	
		// Predefined logging levels.
		Logger.DEBUG = defineLogLevel(1, 'DEBUG');
		Logger.INFO = defineLogLevel(2, 'INFO');
		Logger.TIME = defineLogLevel(3, 'TIME');
		Logger.WARN = defineLogLevel(4, 'WARN');
		Logger.ERROR = defineLogLevel(8, 'ERROR');
		Logger.OFF = defineLogLevel(99, 'OFF');
	
		// Inner class which performs the bulk of the work; ContextualLogger instances can be configured independently
		// of each other.
		var ContextualLogger = function(defaultContext) {
			this.context = defaultContext;
			this.setLevel(defaultContext.filterLevel);
			this.log = this.info;  // Convenience alias.
		};
	
		ContextualLogger.prototype = {
			// Changes the current logging level for the logging instance.
			setLevel: function (newLevel) {
				// Ensure the supplied Level object looks valid.
				if (newLevel && "value" in newLevel) {
					this.context.filterLevel = newLevel;
				}
			},
	
			// Is the logger configured to output messages at the supplied level?
			enabledFor: function (lvl) {
				var filterLevel = this.context.filterLevel;
				return lvl.value >= filterLevel.value;
			},
	
			debug: function () {
				this.invoke(Logger.DEBUG, arguments);
			},
	
			info: function () {
				this.invoke(Logger.INFO, arguments);
			},
	
			warn: function () {
				this.invoke(Logger.WARN, arguments);
			},
	
			error: function () {
				this.invoke(Logger.ERROR, arguments);
			},
	
			time: function (label) {
				if (typeof label === 'string' && label.length > 0) {
					this.invoke(Logger.TIME, [ label, 'start' ]);
				}
			},
	
			timeEnd: function (label) {
				if (typeof label === 'string' && label.length > 0) {
					this.invoke(Logger.TIME, [ label, 'end' ]);
				}
			},
	
			// Invokes the logger callback if it's not being filtered.
			invoke: function (level, msgArgs) {
				if (logHandler && this.enabledFor(level)) {
					logHandler(msgArgs, merge({ level: level }, this.context));
				}
			}
		};
	
		// Protected instance which all calls to the to level `Logger` module will be routed through.
		var globalLogger = new ContextualLogger({ filterLevel: Logger.OFF });
	
		// Configure the global Logger instance.
		(function() {
			// Shortcut for optimisers.
			var L = Logger;
	
			L.enabledFor = bind(globalLogger, globalLogger.enabledFor);
			L.debug = bind(globalLogger, globalLogger.debug);
			L.time = bind(globalLogger, globalLogger.time);
			L.timeEnd = bind(globalLogger, globalLogger.timeEnd);
			L.info = bind(globalLogger, globalLogger.info);
			L.warn = bind(globalLogger, globalLogger.warn);
			L.error = bind(globalLogger, globalLogger.error);
	
			// Don't forget the convenience alias!
			L.log = L.info;
		}());
	
		// Set the global logging handler.  The supplied function should expect two arguments, the first being an arguments
		// object with the supplied log messages and the second being a context object which contains a hash of stateful
		// parameters which the logging function can consume.
		Logger.setHandler = function (func) {
			logHandler = func;
		};
	
		// Sets the global logging filter level which applies to *all* previously registered, and future Logger instances.
		// (note that named loggers (retrieved via `Logger.get`) can be configured independently if required).
		Logger.setLevel = function(level) {
			// Set the globalLogger's level.
			globalLogger.setLevel(level);
	
			// Apply this level to all registered contextual loggers.
			for (var key in contextualLoggersByNameMap) {
				if (contextualLoggersByNameMap.hasOwnProperty(key)) {
					contextualLoggersByNameMap[key].setLevel(level);
				}
			}
		};
	
		// Retrieve a ContextualLogger instance.  Note that named loggers automatically inherit the global logger's level,
		// default context and log handler.
		Logger.get = function (name) {
			// All logger instances are cached so they can be configured ahead of use.
			return contextualLoggersByNameMap[name] ||
				(contextualLoggersByNameMap[name] = new ContextualLogger(merge({ name: name }, globalLogger.context)));
		};
	
		// Configure and example a Default implementation which writes to the `window.console` (if present).  The
		// `options` hash can be used to configure the default logLevel and provide a custom message formatter.
		Logger.useDefaults = function(options) {
			options = options || {};
	
			options.formatter = options.formatter || function defaultMessageFormatter(messages, context) {
				// Prepend the logger's name to the log message for easy identification.
				if (context.name) {
					messages.unshift("[" + context.name + "]");
				}
			};
	
			// Check for the presence of a logger.
			if (typeof console === "undefined") {
				return;
			}
	
			// Map of timestamps by timer labels used to track `#time` and `#timeEnd()` invocations in environments
			// that don't offer a native console method.
			var timerStartTimeByLabelMap = {};
	
			// Support for IE8+ (and other, slightly more sane environments)
			var invokeConsoleMethod = function (hdlr, messages) {
				Function.prototype.apply.call(hdlr, console, messages);
			};
	
			Logger.setLevel(options.defaultLevel || Logger.DEBUG);
			Logger.setHandler(function(messages, context) {
				// Convert arguments object to Array.
				messages = Array.prototype.slice.call(messages);
	
				var hdlr = console.log;
				var timerLabel;
	
				if (context.level === Logger.TIME) {
					timerLabel = (context.name ? '[' + context.name + '] ' : '') + messages[0];
	
					if (messages[1] === 'start') {
						if (console.time) {
							console.time(timerLabel);
						}
						else {
							timerStartTimeByLabelMap[timerLabel] = new Date().getTime();
						}
					}
					else {
						if (console.timeEnd) {
							console.timeEnd(timerLabel);
						}
						else {
							invokeConsoleMethod(hdlr, [ timerLabel + ': ' +
								(new Date().getTime() - timerStartTimeByLabelMap[timerLabel]) + 'ms' ]);
						}
					}
				}
				else {
					// Delegate through to custom warn/error loggers if present on the console.
					if (context.level === Logger.WARN && console.warn) {
						hdlr = console.warn;
					} else if (context.level === Logger.ERROR && console.error) {
						hdlr = console.error;
					} else if (context.level === Logger.INFO && console.info) {
						hdlr = console.info;
					}
	
					options.formatter(messages, context);
					invokeConsoleMethod(hdlr, messages);
				}
			});
		};
	
		// Export to popular environments boilerplate.
		if (true) {
			!(__WEBPACK_AMD_DEFINE_FACTORY__ = (Logger), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.call(exports, __webpack_require__, exports, module)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		}
		else if (typeof module !== 'undefined' && module.exports) {
			module.exports = Logger;
		}
		else {
			Logger._prevLogger = global.Logger;
	
			Logger.noConflict = function () {
				global.Logger = Logger._prevLogger;
				return Logger;
			};
	
			global.Logger = Logger;
		}
	}(this));


/***/ },
/* 3 */
/*!**************************!*\
  !*** ./src/constants.js ***!
  \**************************/
/***/ function(module, exports) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	var NAMESPACE = exports.NAMESPACE = 'rio-rtw-labels';
	
	var ATTRIBUTES = exports.ATTRIBUTES = {
	  BUCKET: 'bucket',
	  CLASSES: {
	    description: 'description',
	    partNumber: 'part_number',
	    serialNumber: 'serial',
	    bucket: 'bucket',
	    location: 'location',
	    group: 'group',
	    category: 'category',
	    position: 'position'
	  },
	  SERIAL_NUMBER_TEXT: 'serialNumberText'
	};
	
	var BARCODE_VENDOR_PREFIX = exports.BARCODE_VENDOR_PREFIX = 'S';
	
	var MESSAGE = exports.MESSAGE = 'message';
	var MESSAGES = exports.MESSAGES = {
	  ERROR: 'error',
	  PRINT: 'print'
	};
	
	var OBSERVATIONS = exports.OBSERVATIONS = {
	  ASSETS: 'assets',
	  ASSETS_PARENT: 'assetsParent'
	};
	
	var QUERIES = exports.QUERIES = {
	  ASSETS: '.search-details-list',
	  ASSETS_PARENT: '.master .body',
	  ASSETS_SELECTED: '.search-details-item.selected',
	  PRINT_BUTTON: id(ns('print', 'button')),
	  PRINT_ROW: id(ns('print', 'row')),
	  PRINT_ROW_PARENT: '#reports > .table'
	};
	
	var SETTINGS = exports.SETTINGS = {
	  OVERRIDE_PRINTER_NAME: 'overridePrinterName',
	  USE_DEFAULT_PRINTER: 'useDefaultPrinter'
	};
	
	var UNDEFINED = exports.UNDEFINED = 'undefined';
	
	function id(value) {
	  return '#' + value;
	}
	
	function ns() {
	  var separator = '__';
	
	  for (var _len = arguments.length, values = Array(_len), _key = 0; _key < _len; _key++) {
	    values[_key] = arguments[_key];
	  }
	
	  return [NAMESPACE].concat(values).join(separator);
	}

/***/ },
/* 4 */
/*!***********************!*\
  !*** ./src/safari.js ***!
  \***********************/
/***/ function(module, exports) {

	"use strict";
	
	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	
	exports.default = function () {
	  return safari;
	}(); // eslint-disable-line no-undef

/***/ },
/* 5 */
/*!***********************************!*\
  !*** ./src/messageHandlerShim.js ***!
  \***********************************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	
	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol ? "symbol" : typeof obj; };
	
	var _constants = __webpack_require__(/*! constants */ 3);
	
	var messageHandlerShim = function messageHandlerShim(handlers) {
	  return function (event) {
	    var name = event.name;
	
	    var handler = handlers[name];
	
	    if ((typeof handler === 'undefined' ? 'undefined' : _typeof(handler)) !== _constants.UNDEFINED) return handler(event);
	
	    return handlers.unknown(event);
	  };
	};
	
	exports.default = messageHandlerShim;

/***/ },
/* 6 */
/*!******************************************!*\
  !*** ./src/end/messageHandlers/index.js ***!
  \******************************************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	exports.unknown = exports.error = undefined;
	
	var _error2 = __webpack_require__(/*! end/messageHandlers/error */ 7);
	
	var _error3 = _interopRequireDefault(_error2);
	
	var _unknown2 = __webpack_require__(/*! end/messageHandlers/unknown */ 8);
	
	var _unknown3 = _interopRequireDefault(_unknown2);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	exports.error = _error3.default;
	exports.unknown = _unknown3.default;

/***/ },
/* 7 */
/*!******************************************!*\
  !*** ./src/end/messageHandlers/error.js ***!
  \******************************************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	
	var _jsLogger = __webpack_require__(/*! js-logger */ 2);
	
	var _jsLogger2 = _interopRequireDefault(_jsLogger);
	
	var _constants = __webpack_require__(/*! constants */ 3);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	var error = function error(event) {
	  var payload = event.message;
	
	
	  _jsLogger2.default.info('Message received', _constants.MESSAGES.ERROR, payload);
	
	  _jsLogger2.default.error(payload);
	};
	
	exports.default = error;

/***/ },
/* 8 */
/*!********************************************!*\
  !*** ./src/end/messageHandlers/unknown.js ***!
  \********************************************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	
	var _jsLogger = __webpack_require__(/*! js-logger */ 2);
	
	var _jsLogger2 = _interopRequireDefault(_jsLogger);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	var unknown = function unknown(event) {
	  var type = event.name;
	  var payload = event.message;
	
	
	  _jsLogger2.default.info('Message received', type, payload);
	
	  _jsLogger2.default.error('Message type not supported', type);
	};
	
	exports.default = unknown;

/***/ },
/* 9 */
/*!**********************************!*\
  !*** ./src/end/actions/index.js ***!
  \**********************************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	exports.print = exports.observe = exports.injectPrintButton = exports.dispatchMessage = undefined;
	
	var _dispatchMessage2 = __webpack_require__(/*! end/actions/dispatchMessage */ 10);
	
	var _dispatchMessage3 = _interopRequireDefault(_dispatchMessage2);
	
	var _injectPrintButton2 = __webpack_require__(/*! end/actions/injectPrintButton */ 11);
	
	var _injectPrintButton3 = _interopRequireDefault(_injectPrintButton2);
	
	var _observe2 = __webpack_require__(/*! end/actions/observe */ 18);
	
	var _observe3 = _interopRequireDefault(_observe2);
	
	var _print2 = __webpack_require__(/*! end/actions/print */ 22);
	
	var _print3 = _interopRequireDefault(_print2);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	exports.dispatchMessage = _dispatchMessage3.default;
	exports.injectPrintButton = _injectPrintButton3.default;
	exports.observe = _observe3.default;
	exports.print = _print3.default;

/***/ },
/* 10 */
/*!********************************************!*\
  !*** ./src/end/actions/dispatchMessage.js ***!
  \********************************************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	
	var _jsLogger = __webpack_require__(/*! js-logger */ 2);
	
	var _jsLogger2 = _interopRequireDefault(_jsLogger);
	
	var _safari = __webpack_require__(/*! safari */ 4);
	
	var _safari2 = _interopRequireDefault(_safari);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	var dispatchMessage = function dispatchMessage() {
	  var _Safari$self$tab;
	
	  for (var _len = arguments.length, message = Array(_len), _key = 0; _key < _len; _key++) {
	    message[_key] = arguments[_key];
	  }
	
	  _jsLogger2.default.info.apply(_jsLogger2.default, ['Dispatching message'].concat(message));
	  (_Safari$self$tab = _safari2.default.self.tab).dispatchMessage.apply(_Safari$self$tab, message);
	};
	
	exports.default = dispatchMessage;

/***/ },
/* 11 */
/*!**********************************************!*\
  !*** ./src/end/actions/injectPrintButton.js ***!
  \**********************************************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	exports.default = injectPrintButton;
	
	var _jsLogger = __webpack_require__(/*! js-logger */ 2);
	
	var _jsLogger2 = _interopRequireDefault(_jsLogger);
	
	var _hyperscript = __webpack_require__(/*! hyperscript */ 12);
	
	var _hyperscript2 = _interopRequireDefault(_hyperscript);
	
	var _constants = __webpack_require__(/*! constants */ 3);
	
	var _actions = __webpack_require__(/*! end/actions */ 9);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	function injectPrintButton() {
	  var parent = document.querySelector(_constants.QUERIES.PRINT_ROW_PARENT);
	
	  if (parent) {
	    _jsLogger2.default.info('Injecting print button');
	    parent.appendChild(button());
	  }
	}
	
	function button() {
	  // Used to pluralize button label.
	  var selected = document.querySelectorAll(_constants.QUERIES.ASSETS_SELECTED);
	  var text = 'Print RTW ' + pluralize('Label', selected.length);
	
	  return (0, _hyperscript2.default)('li.table-row' + _constants.QUERIES.PRINT_ROW, (0, _hyperscript2.default)('label', text), (0, _hyperscript2.default)('button.download' + _constants.QUERIES.PRINT_BUTTON, { style: style, onclick: onclick }));
	}
	
	function onclick(event) {
	  event.preventDefault();
	  (0, _actions.print)();
	}
	
	function pluralize(word, n) {
	  if (n == 1) return word;
	  return word + 's';
	}
	
	var style = {
	  'background-image': 'url(' + __webpack_require__(/*! url!assets/print.svg */ 17) + ')'
	};

/***/ },
/* 12 */
/*!********************************!*\
  !*** ./~/hyperscript/index.js ***!
  \********************************/
/***/ function(module, exports, __webpack_require__) {

	var split = __webpack_require__(/*! browser-split */ 13)
	var ClassList = __webpack_require__(/*! class-list */ 14)
	__webpack_require__(/*! html-element */ 16)
	
	function context () {
	
	  var cleanupFuncs = []
	
	  function h() {
	    var args = [].slice.call(arguments), e = null
	    function item (l) {
	      var r
	      function parseClass (string) {
	        // Our minimal parser doesn’t understand escaping CSS special
	        // characters like `#`. Don’t use them. More reading:
	        // https://mathiasbynens.be/notes/css-escapes .
	
	        var m = split(string, /([\.#]?[^\s#.]+)/)
	        if(/^\.|#/.test(m[1]))
	          e = document.createElement('div')
	        forEach(m, function (v) {
	          var s = v.substring(1,v.length)
	          if(!v) return
	          if(!e)
	            e = document.createElement(v)
	          else if (v[0] === '.')
	            ClassList(e).add(s)
	          else if (v[0] === '#')
	            e.setAttribute('id', s)
	        })
	      }
	
	      if(l == null)
	        ;
	      else if('string' === typeof l) {
	        if(!e)
	          parseClass(l)
	        else
	          e.appendChild(r = document.createTextNode(l))
	      }
	      else if('number' === typeof l
	        || 'boolean' === typeof l
	        || l instanceof Date
	        || l instanceof RegExp ) {
	          e.appendChild(r = document.createTextNode(l.toString()))
	      }
	      //there might be a better way to handle this...
	      else if (isArray(l))
	        forEach(l, item)
	      else if(isNode(l))
	        e.appendChild(r = l)
	      else if(l instanceof Text)
	        e.appendChild(r = l)
	      else if ('object' === typeof l) {
	        for (var k in l) {
	          if('function' === typeof l[k]) {
	            if(/^on\w+/.test(k)) {
	              (function (k, l) { // capture k, l in the closure
	                if (e.addEventListener){
	                  e.addEventListener(k.substring(2), l[k], false)
	                  cleanupFuncs.push(function(){
	                    e.removeEventListener(k.substring(2), l[k], false)
	                  })
	                }else{
	                  e.attachEvent(k, l[k])
	                  cleanupFuncs.push(function(){
	                    e.detachEvent(k, l[k])
	                  })
	                }
	              })(k, l)
	            } else {
	              // observable
	              e[k] = l[k]()
	              cleanupFuncs.push(l[k](function (v) {
	                e[k] = v
	              }))
	            }
	          }
	          else if(k === 'style') {
	            if('string' === typeof l[k]) {
	              e.style.cssText = l[k]
	            }else{
	              for (var s in l[k]) (function(s, v) {
	                if('function' === typeof v) {
	                  // observable
	                  e.style.setProperty(s, v())
	                  cleanupFuncs.push(v(function (val) {
	                    e.style.setProperty(s, val)
	                  }))
	                } else
	                  e.style.setProperty(s, l[k][s])
	              })(s, l[k][s])
	            }
	          } else if (k.substr(0, 5) === "data-") {
	            e.setAttribute(k, l[k])
	          } else {
	            e[k] = l[k]
	          }
	        }
	      } else if ('function' === typeof l) {
	        //assume it's an observable!
	        var v = l()
	        e.appendChild(r = isNode(v) ? v : document.createTextNode(v))
	
	        cleanupFuncs.push(l(function (v) {
	          if(isNode(v) && r.parentElement)
	            r.parentElement.replaceChild(v, r), r = v
	          else
	            r.textContent = v
	        }))
	      }
	
	      return r
	    }
	    while(args.length)
	      item(args.shift())
	
	    return e
	  }
	
	  h.cleanup = function () {
	    for (var i = 0; i < cleanupFuncs.length; i++){
	      cleanupFuncs[i]()
	    }
	    cleanupFuncs.length = 0
	  }
	
	  return h
	}
	
	var h = module.exports = context()
	h.context = context
	
	function isNode (el) {
	  return el && el.nodeName && el.nodeType
	}
	
	function isText (el) {
	  return el && el.nodeName === '#text' && el.nodeType == 3
	}
	
	function forEach (arr, fn) {
	  if (arr.forEach) return arr.forEach(fn)
	  for (var i = 0; i < arr.length; i++) fn(arr[i], i)
	}
	
	function isArray (arr) {
	  return Object.prototype.toString.call(arr) == '[object Array]'
	}


/***/ },
/* 13 */
/*!**********************************!*\
  !*** ./~/browser-split/index.js ***!
  \**********************************/
/***/ function(module, exports) {

	/*!
	 * Cross-Browser Split 1.1.1
	 * Copyright 2007-2012 Steven Levithan <stevenlevithan.com>
	 * Available under the MIT License
	 * ECMAScript compliant, uniform cross-browser split method
	 */
	
	/**
	 * Splits a string into an array of strings using a regex or string separator. Matches of the
	 * separator are not included in the result array. However, if `separator` is a regex that contains
	 * capturing groups, backreferences are spliced into the result each time `separator` is matched.
	 * Fixes browser bugs compared to the native `String.prototype.split` and can be used reliably
	 * cross-browser.
	 * @param {String} str String to split.
	 * @param {RegExp|String} separator Regex or string to use for separating the string.
	 * @param {Number} [limit] Maximum number of items to include in the result array.
	 * @returns {Array} Array of substrings.
	 * @example
	 *
	 * // Basic use
	 * split('a b c d', ' ');
	 * // -> ['a', 'b', 'c', 'd']
	 *
	 * // With limit
	 * split('a b c d', ' ', 2);
	 * // -> ['a', 'b']
	 *
	 * // Backreferences in result array
	 * split('..word1 word2..', /([a-z]+)(\d+)/i);
	 * // -> ['..', 'word', '1', ' ', 'word', '2', '..']
	 */
	module.exports = (function split(undef) {
	
	  var nativeSplit = String.prototype.split,
	    compliantExecNpcg = /()??/.exec("")[1] === undef,
	    // NPCG: nonparticipating capturing group
	    self;
	
	  self = function(str, separator, limit) {
	    // If `separator` is not a regex, use `nativeSplit`
	    if (Object.prototype.toString.call(separator) !== "[object RegExp]") {
	      return nativeSplit.call(str, separator, limit);
	    }
	    var output = [],
	      flags = (separator.ignoreCase ? "i" : "") + (separator.multiline ? "m" : "") + (separator.extended ? "x" : "") + // Proposed for ES6
	      (separator.sticky ? "y" : ""),
	      // Firefox 3+
	      lastLastIndex = 0,
	      // Make `global` and avoid `lastIndex` issues by working with a copy
	      separator = new RegExp(separator.source, flags + "g"),
	      separator2, match, lastIndex, lastLength;
	    str += ""; // Type-convert
	    if (!compliantExecNpcg) {
	      // Doesn't need flags gy, but they don't hurt
	      separator2 = new RegExp("^" + separator.source + "$(?!\\s)", flags);
	    }
	    /* Values for `limit`, per the spec:
	     * If undefined: 4294967295 // Math.pow(2, 32) - 1
	     * If 0, Infinity, or NaN: 0
	     * If positive number: limit = Math.floor(limit); if (limit > 4294967295) limit -= 4294967296;
	     * If negative number: 4294967296 - Math.floor(Math.abs(limit))
	     * If other: Type-convert, then use the above rules
	     */
	    limit = limit === undef ? -1 >>> 0 : // Math.pow(2, 32) - 1
	    limit >>> 0; // ToUint32(limit)
	    while (match = separator.exec(str)) {
	      // `separator.lastIndex` is not reliable cross-browser
	      lastIndex = match.index + match[0].length;
	      if (lastIndex > lastLastIndex) {
	        output.push(str.slice(lastLastIndex, match.index));
	        // Fix browsers whose `exec` methods don't consistently return `undefined` for
	        // nonparticipating capturing groups
	        if (!compliantExecNpcg && match.length > 1) {
	          match[0].replace(separator2, function() {
	            for (var i = 1; i < arguments.length - 2; i++) {
	              if (arguments[i] === undef) {
	                match[i] = undef;
	              }
	            }
	          });
	        }
	        if (match.length > 1 && match.index < str.length) {
	          Array.prototype.push.apply(output, match.slice(1));
	        }
	        lastLength = match[0].length;
	        lastLastIndex = lastIndex;
	        if (output.length >= limit) {
	          break;
	        }
	      }
	      if (separator.lastIndex === match.index) {
	        separator.lastIndex++; // Avoid an infinite loop
	      }
	    }
	    if (lastLastIndex === str.length) {
	      if (lastLength || !separator.test("")) {
	        output.push("");
	      }
	    } else {
	      output.push(str.slice(lastLastIndex));
	    }
	    return output.length > limit ? output.slice(0, limit) : output;
	  };
	
	  return self;
	})();


/***/ },
/* 14 */
/*!*******************************!*\
  !*** ./~/class-list/index.js ***!
  \*******************************/
/***/ function(module, exports, __webpack_require__) {

	// contains, add, remove, toggle
	var indexof = __webpack_require__(/*! indexof */ 15)
	
	module.exports = ClassList
	
	function ClassList(elem) {
	    var cl = elem.classList
	
	    if (cl) {
	        return cl
	    }
	
	    var classList = {
	        add: add
	        , remove: remove
	        , contains: contains
	        , toggle: toggle
	        , toString: $toString
	        , length: 0
	        , item: item
	    }
	
	    return classList
	
	    function add(token) {
	        var list = getTokens()
	        if (indexof(list, token) > -1) {
	            return
	        }
	        list.push(token)
	        setTokens(list)
	    }
	
	    function remove(token) {
	        var list = getTokens()
	            , index = indexof(list, token)
	
	        if (index === -1) {
	            return
	        }
	
	        list.splice(index, 1)
	        setTokens(list)
	    }
	
	    function contains(token) {
	        return indexof(getTokens(), token) > -1
	    }
	
	    function toggle(token) {
	        if (contains(token)) {
	            remove(token)
	            return false
	        } else {
	            add(token)
	            return true
	        }
	    }
	
	    function $toString() {
	        return elem.className
	    }
	
	    function item(index) {
	        var tokens = getTokens()
	        return tokens[index] || null
	    }
	
	    function getTokens() {
	        var className = elem.className
	
	        return filter(className.split(" "), isTruthy)
	    }
	
	    function setTokens(list) {
	        var length = list.length
	
	        elem.className = list.join(" ")
	        classList.length = length
	
	        for (var i = 0; i < list.length; i++) {
	            classList[i] = list[i]
	        }
	
	        delete list[length]
	    }
	}
	
	function filter (arr, fn) {
	    var ret = []
	    for (var i = 0; i < arr.length; i++) {
	        if (fn(arr[i])) ret.push(arr[i])
	    }
	    return ret
	}
	
	function isTruthy(value) {
	    return !!value
	}


/***/ },
/* 15 */
/*!****************************!*\
  !*** ./~/indexof/index.js ***!
  \****************************/
/***/ function(module, exports) {

	
	var indexOf = [].indexOf;
	
	module.exports = function(arr, obj){
	  if (indexOf) return arr.indexOf(obj);
	  for (var i = 0; i < arr.length; ++i) {
	    if (arr[i] === obj) return i;
	  }
	  return -1;
	};

/***/ },
/* 16 */
/*!******************************!*\
  !*** html-element (ignored) ***!
  \******************************/
/***/ function(module, exports) {

	/* (ignored) */

/***/ },
/* 17 */
/*!*********************************************!*\
  !*** ./~/url-loader!./src/assets/print.svg ***!
  \*********************************************/
/***/ function(module, exports) {

	module.exports = "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+Cjxzdmcgd2lkdGg9Ijg4cHgiIGhlaWdodD0iODhweCIgdmlld0JveD0iMCAwIDg4IDg4IiB2ZXJzaW9uPSIxLjEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPgogICAgPCEtLSBHZW5lcmF0b3I6IFNrZXRjaCAzLjYuMSAoMjYzMTMpIC0gaHR0cDovL3d3dy5ib2hlbWlhbmNvZGluZy5jb20vc2tldGNoIC0tPgogICAgPHRpdGxlPkRlc2t0b3AgSEQ8L3RpdGxlPgogICAgPGRlc2M+Q3JlYXRlZCB3aXRoIFNrZXRjaC48L2Rlc2M+CiAgICA8ZGVmcz48L2RlZnM+CiAgICA8ZyBpZD0iUGFnZS0xIiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj4KICAgICAgICA8ZyBpZD0iRGVza3RvcC1IRCIgc3Ryb2tlPSIjN0UzRjk4IiBzdHJva2Utd2lkdGg9IjAuNSIgZmlsbD0iIzdFM0Y5OCI+CiAgICAgICAgICAgIDxnIGlkPSJpb3MtcHJpbnRlci1vdXRsaW5lIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgyMC4wMDAwMDAsIDIyLjAwMDAwMCkiPgogICAgICAgICAgICAgICAgPHBhdGggZD0iTTQ0LjM2NTM4NDYsNS41Mzg0NjE1NCBMNDAuNjE1Mzg0Niw1LjUzODQ2MTU0IEw0MC42MTUzODQ2LC0zLjU1MjcxMzY4ZS0xNSBMNy4zODQ2MTUzOCwtMy41NTI3MTM2OGUtMTUgTDcuMzg0NjE1MzgsNS41Mzg0NjE1NCBMMy43NSw1LjUzODQ2MTU0IEMxLjcxOTIzMDc3LDUuNTM4NDYxNTQgMCw3LjEzMDc2OTIzIDAsOS4xNSBMMCwyNy40MjY5MjMxIEMwLDI5LjQ0NjE1MzggMS43MTkyMzA3NywzMS4xNTM4NDYyIDMuNzUsMzEuMTUzODQ2MiBMOS4yMzA3NjkyMywzMS4xNTM4NDYyIEw5LjIzMDc2OTIzLDQ0LjMwNzY5MjMgTDM4Ljc2OTIzMDgsNDQuMzA3NjkyMyBMMzguNzY5MjMwOCwzMS4xNTM4NDYyIEw0NC4zNjUzODQ2LDMxLjE1Mzg0NjIgQzQ2LjM5NjE1MzgsMzEuMTUzODQ2MiA0OCwyOS40NDYxNTM4IDQ4LDI3LjQyNjkyMzEgTDQ4LDkuMTUgQzQ4LDcuMTMwNzY5MjMgNDYuMzk2MTUzOCw1LjUzODQ2MTU0IDQ0LjM2NTM4NDYsNS41Mzg0NjE1NCBMNDQuMzY1Mzg0Niw1LjUzODQ2MTU0IFogTTkuMjMwNzY5MjMsMS44NDYxNTM4NSBMMzguNzY5MjMwOCwxLjg0NjE1Mzg1IEwzOC43NjkyMzA4LDUuNTM4NDYxNTQgTDkuMjMwNzY5MjMsNS41Mzg0NjE1NCBMOS4yMzA3NjkyMywxLjg0NjE1Mzg1IEw5LjIzMDc2OTIzLDEuODQ2MTUzODUgWiBNMzYuOTIzMDc2OSw0Mi40NjE1Mzg1IEwxMS4wNzY5MjMxLDQyLjQ2MTUzODUgTDExLjA3NjkyMzEsMjAuMzA3NjkyMyBMMzYuOTIzMDc2OSwyMC4zMDc2OTIzIEwzNi45MjMwNzY5LDQyLjQ2MTUzODUgTDM2LjkyMzA3NjksNDIuNDYxNTM4NSBaIE00Ni4xNTM4NDYyLDI3LjQyNjkyMzEgQzQ2LjE1Mzg0NjIsMjguNDMwNzY5MiA0NS4zODA3NjkyLDI5LjMwNzY5MjMgNDQuMzY1Mzg0NiwyOS4zMDc2OTIzIEwzOC43NjkyMzA4LDI5LjMwNzY5MjMgTDM4Ljc2OTIzMDgsMTguNDYxNTM4NSBMOS4yMzA3NjkyMywxOC40NjE1Mzg1IEw5LjIzMDc2OTIzLDI5LjMwNzY5MjMgTDMuNzUsMjkuMzA3NjkyMyBDMi43MzQ2MTUzOCwyOS4zMDc2OTIzIDEuODQ2MTUzODUsMjguNDMwNzY5MiAxLjg0NjE1Mzg1LDI3LjQyNjkyMzEgTDEuODQ2MTUzODUsOS4xNSBDMS44NDYxNTM4NSw4LjE0NjE1Mzg1IDIuNzM0NjE1MzgsNy4zODQ2MTUzOCAzLjc1LDcuMzg0NjE1MzggTDQ0LjMwNzY5MjMsNy4zODQ2MTUzOCBMNDQuMzY1Mzg0Niw3LjM4NDYxNTM4IEM0NS4zODA3NjkyLDcuMzg0NjE1MzggNDYuMTUzODQ2Miw4LjE0NjE1Mzg1IDQ2LjE1Mzg0NjIsOS4xNSBMNDYuMTUzODQ2MiwyNy40MjY5MjMxIEw0Ni4xNTM4NDYyLDI3LjQyNjkyMzEgWiIgaWQ9IlNoYXBlIj48L3BhdGg+CiAgICAgICAgICAgIDwvZz4KICAgICAgICA8L2c+CiAgICA8L2c+Cjwvc3ZnPg=="

/***/ },
/* 18 */
/*!************************************!*\
  !*** ./src/end/actions/observe.js ***!
  \************************************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	exports.default = observe;
	
	var _jsLogger = __webpack_require__(/*! js-logger */ 2);
	
	var _jsLogger2 = _interopRequireDefault(_jsLogger);
	
	var _mutationHandlers = __webpack_require__(/*! end/mutationHandlers */ 19);
	
	var mutationHandlers = _interopRequireWildcard(_mutationHandlers);
	
	function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	function observe(observation, query, config) {
	  var observer = new MutationObserver(function (mutations) {
	    mutations.forEach(mutationHandlers[observation](observer));
	  });
	
	  var target = document.querySelector(query);
	
	  observer.observe(target, config);
	  _jsLogger2.default.info('Now observing mutations', observation);
	
	  return observer;
	}

/***/ },
/* 19 */
/*!*******************************************!*\
  !*** ./src/end/mutationHandlers/index.js ***!
  \*******************************************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	exports.assetsParent = exports.assets = undefined;
	
	var _assets2 = __webpack_require__(/*! end/mutationHandlers/assets */ 20);
	
	var _assets3 = _interopRequireDefault(_assets2);
	
	var _assetsParent2 = __webpack_require__(/*! end/mutationHandlers/assetsParent */ 21);
	
	var _assetsParent3 = _interopRequireDefault(_assetsParent2);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	exports.assets = _assets3.default;
	exports.assetsParent = _assetsParent3.default;

/***/ },
/* 20 */
/*!********************************************!*\
  !*** ./src/end/mutationHandlers/assets.js ***!
  \********************************************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	
	var _jsLogger = __webpack_require__(/*! js-logger */ 2);
	
	var _jsLogger2 = _interopRequireDefault(_jsLogger);
	
	var _constants = __webpack_require__(/*! constants */ 3);
	
	var _actions = __webpack_require__(/*! end/actions */ 9);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	var assets = function assets(_observer) {
	  return function (mutation) {
	    _jsLogger2.default.info('Mutation received', _constants.OBSERVATIONS.ASSETS, mutation);
	
	    var selected = document.querySelectorAll(_constants.QUERIES.ASSETS_SELECTED);
	    var existingButton = document.querySelector(_constants.QUERIES.PRINT_BUTTON);
	
	    if (selected.length && !existingButton) (0, _actions.injectPrintButton)();
	  };
	};
	
	exports.default = assets;

/***/ },
/* 21 */
/*!**************************************************!*\
  !*** ./src/end/mutationHandlers/assetsParent.js ***!
  \**************************************************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	
	var _jsLogger = __webpack_require__(/*! js-logger */ 2);
	
	var _jsLogger2 = _interopRequireDefault(_jsLogger);
	
	var _constants = __webpack_require__(/*! constants */ 3);
	
	var _actions = __webpack_require__(/*! end/actions */ 9);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }
	
	var assetsParent = function assetsParent(observer) {
	  return function (mutation) {
	    _jsLogger2.default.info('Mutation received', _constants.OBSERVATIONS.ASSETS_PARENT, mutation);
	
	    var addedNodes = [].concat(_toConsumableArray(mutation.addedNodes));
	    var klasses = addedNodes.map(function (node) {
	      return node.className;
	    });
	    var klass = _constants.QUERIES.ASSETS.substr(1);
	
	    if (klasses.includes(klass)) {
	      (0, _actions.observe)(_constants.OBSERVATIONS.ASSETS, _constants.QUERIES.ASSETS, {
	        attributes: true,
	        attributeFilter: ['class'],
	        childNodes: true,
	        subtree: true
	      });
	
	      observer.disconnect();
	      _jsLogger2.default.info('No longer observing mutations', _constants.OBSERVATIONS.ASSETS_PARENT);
	    }
	  };
	};
	
	exports.default = assetsParent;

/***/ },
/* 22 */
/*!**********************************!*\
  !*** ./src/end/actions/print.js ***!
  \**********************************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	exports.default = print;
	
	var _jsLogger = __webpack_require__(/*! js-logger */ 2);
	
	var _jsLogger2 = _interopRequireDefault(_jsLogger);
	
	var _constants = __webpack_require__(/*! constants */ 3);
	
	var _actions = __webpack_require__(/*! end/actions */ 9);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }
	
	function print() {
	  var assets = selectedAssets();
	
	  if (assets.length < 1) {
	    _jsLogger2.default.warn('No assets selected to print');
	    return;
	  }
	
	  (0, _actions.dispatchMessage)(_constants.MESSAGES.PRINT, assets);
	}
	
	function selectedAssets() {
	  var elements = document.querySelectorAll(_constants.QUERIES.ASSETS_SELECTED);
	  var assets = [].concat(_toConsumableArray(elements));
	  return assets.map(elementToAsset);
	}
	
	function elementToAsset(element) {
	  var asset = {};
	
	  for (var key in _constants.ATTRIBUTES.CLASSES) {
	    var klass = _constants.ATTRIBUTES.CLASSES[key];
	    var value = element.querySelector('.' + klass).innerText;
	    asset[key] = value;
	  }
	
	  return asset;
	}

/***/ }
/******/ ]);
//# sourceMappingURL=end.js.map